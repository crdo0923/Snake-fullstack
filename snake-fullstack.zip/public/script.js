const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const box = 20;
let snake = [{ x: 9 * box, y: 10 * box }];
let direction = null;
let food = spawnFood();
let score = 0;

document.addEventListener("keydown", dir);
function dir(e) {
  if (e.key === "ArrowLeft" || e.key === "a") direction = "LEFT";
  if (e.key === "ArrowUp" || e.key === "w") direction = "UP";
  if (e.key === "ArrowRight" || e.key === "d") direction = "RIGHT";
  if (e.key === "ArrowDown" || e.key === "s") direction = "DOWN";
}
function draw() {
  ctx.fillStyle = "#222";
  ctx.fillRect(0, 0, 400, 400);
  for (let i = 0; i < snake.length; i++) {
    ctx.fillStyle = i == 0 ? "lime" : "white";
    ctx.fillRect(snake[i].x, snake[i].y, box, box);
  }
  ctx.fillStyle = "red";
  ctx.fillRect(food.x, food.y, box, box);
  let headX = snake[0].x;
  let headY = snake[0].y;
  if (direction == "LEFT") headX -= box;
  if (direction == "RIGHT") headX += box;
  if (direction == "UP") headY -= box;
  if (direction == "DOWN") headY += box;
  if (
    headX < 0 || headX >= 400 || headY < 0 || headY >= 400 ||
    snake.some(seg => seg.x == headX && seg.y == headY)
  ) {
    clearInterval(game);
    alert("Game Over!");
    return;
  }
  let newHead = { x: headX, y: headY };
  if (headX == food.x && headY == food.y) {
    score++;
    food = spawnFood();
  } else {
    snake.pop();
  }
  snake.unshift(newHead);
  document.getElementById("score").innerText = "Score: " + score;
}
function spawnFood() {
  return {
    x: Math.floor(Math.random() * 20) * box,
    y: Math.floor(Math.random() * 20) * box
  };
}
function saveScore() {
  const name = document.getElementById("playerName").value.trim();
  if (!name) return alert("Enter name first.");
  fetch('/api/score', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, score })
  }).then(() => {
    loadScores();
    score = 0;
    snake = [{ x: 9 * box, y: 10 * box }];
    direction = null;
    food = spawnFood();
  });
}
function loadScores() {
  fetch('/api/scores')
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("leaderboard");
      list.innerHTML = "";
      data.forEach(s => {
        const li = document.createElement("li");
        li.innerText = `${s.name}: ${s.score}`;
        list.appendChild(li);
      });
    });
}
loadScores();
const game = setInterval(draw, 100);
