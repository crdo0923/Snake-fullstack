const express = require('express');
const path = require('path');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');
const { nanoid } = require('nanoid');

const app = express();
const PORT = 3000;

const db = new Low(new JSONFile('db.json'));
await db.read();
db.data ||= { scores: [] };

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.post('/api/score', async (req, res) => {
  const { name, score } = req.body;
  if (!name || score == null) return res.status(400).send("Invalid");
  db.data.scores.push({ id: nanoid(), name, score });
  db.data.scores.sort((a, b) => b.score - a.score);
  db.data.scores = db.data.scores.slice(0, 10);
  await db.write();
  res.send({ success: true });
});

app.get('/api/scores', async (req, res) => {
  await db.read();
  res.send(db.data.scores);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
